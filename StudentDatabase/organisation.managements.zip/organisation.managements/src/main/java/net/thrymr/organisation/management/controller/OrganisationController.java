package net.thrymr.organisation.management.controller;

import net.thrymr.organisation.management.dto.AddressDto;
import net.thrymr.organisation.management.dto.DepartmentDto;
import net.thrymr.organisation.management.dto.OrganisationDto;
import net.thrymr.organisation.management.service.OrderBy;
import net.thrymr.organisation.management.service.serviceInterface.DepartmentService;
import net.thrymr.organisation.management.service.serviceInterface.OrganisationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/organisation")
public class OrganisationController {
    @Autowired
    public OrganisationService organisationService;

    @Autowired
    public DepartmentService departmentService;
    @PostMapping(path = "/save")
    public OrganisationDto save(@RequestBody OrganisationDto organisationDto){
        return organisationService.saveOrganisation(organisationDto);
    }

    @DeleteMapping(path = "/delete/{id}")
    public boolean deleteOrganisation(@PathVariable("id") Long id){
        return organisationService.deleteById(id);
    }
    @GetMapping(path = "/get-all")
    public List<OrganisationDto> getAll(){
        return organisationService.getAll();
    }
    @GetMapping(path = "/find-by-id/{id}")
    public OrganisationDto findById(@PathVariable("id") Long id){
        return organisationService.findById(id);
    }
    @PutMapping(path = "/update-address")
    public AddressDto saveAddress(@RequestBody AddressDto addressDto){
        return organisationService.updateAddress(addressDto);
    }
    @DeleteMapping(path = "/delete-Address/{id}")
    public boolean deleteAddressById(@PathVariable("id") Long id){
        return organisationService.deleteAddressById(id);
    }
    @GetMapping("find-order-by/{orderBy}")
    public List<OrganisationDto> findByOrder(@PathVariable("orderBy") OrderBy order){
        return organisationService.findByOrderByAsc(order);
    }
    @GetMapping("order-by/{field}/{request}")
    public List<OrganisationDto> findOrderByLength(@PathVariable("field") String field,  @PathVariable("request") OrderBy order){
        return organisationService.getLengthSortedOrder(field,order);
    }
    @GetMapping("send-dept-details/{id}")
    public List<DepartmentDto> sendDeptList(@PathVariable Long id){
        return organisationService.sendDepartmentList(id);
    }
    @PutMapping(path = "/update-department/{id}")
    public DepartmentDto updateDepartment(@PathVariable Long id, @RequestBody DepartmentDto departmentDto){
        return departmentService.updateDepartment(id, departmentDto);
    }
    @DeleteMapping(path = "/department-delete/{id}")
    public boolean deleteDepartment(@PathVariable("id") Long id){
        return departmentService.deleteById(id);
    }
    @GetMapping(path = "/get-all-department")
    public List<DepartmentDto> getAllDepartments(){
        return departmentService.getAll();
    }
    @PostMapping(path = "/save-all-department/{id}")
    public List<DepartmentDto>   saveListDepartments(@PathVariable Long id, @RequestBody List<DepartmentDto> departmentDto) {
        return departmentService.saveListDepartment(id, departmentDto);
    }
    @GetMapping(path = "/get-address/{id}")
    public AddressDto sendOrganisationAddress(@PathVariable Long id){
        return organisationService.sendOrganisationAddress(id);
    }
}