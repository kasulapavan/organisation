package net.thrymr.organisation.management.service;

import net.thrymr.organisation.management.dto.AddressDto;
import net.thrymr.organisation.management.dto.DepartmentDto;
import net.thrymr.organisation.management.dto.OrganisationDto;
import net.thrymr.organisation.management.entity.Address;
import net.thrymr.organisation.management.entity.Department;
import net.thrymr.organisation.management.entity.Organisation;
import net.thrymr.organisation.management.repository.AddressRepository;
import net.thrymr.organisation.management.repository.OrganisationRepository;
import net.thrymr.organisation.management.service.serviceInterface.OrganisationService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class OrganisationServiceImplementation implements OrganisationService {
    @Autowired
    public OrganisationRepository organisationRepository;

    @Autowired
    public AddressRepository addressRepository;


    @Autowired
    public ModelMapper modelMapper;

    @Override
    public OrganisationDto saveOrganisation(OrganisationDto organisationDto) {
        Organisation organisation = modelMapper.map(organisationDto, Organisation.class);
        return modelMapper.map(organisationRepository.save(organisation), OrganisationDto.class);

    }

    @Override
    public boolean deleteById(Long id) {
        try {
            organisationRepository.deleteById(id);
            return true;
        } catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }

    @Override
    public List<OrganisationDto> getAll() {
        List<Organisation> organisations = organisationRepository.findAll();
        return organisations.stream().map(organisation -> modelMapper.map(organisation, OrganisationDto.class)).toList();
    }

    @Override
    public OrganisationDto findById(Long id) {
        return modelMapper.map(organisationRepository.findById(id).get(), OrganisationDto.class);
    }

    @Override
    public AddressDto updateAddress(AddressDto addressDto) {
        Address address = modelMapper.map(addressDto, Address.class);
        return modelMapper.map(addressRepository.save(address), AddressDto.class);
    }

    public boolean deleteAddressById(Long addressId) {
        try {
            addressRepository.deleteById(addressId);
            return true;
        } catch (Exception exception) {
            exception.printStackTrace();
            return false;
        }
    }

    @Override
    public List<OrganisationDto> findByOrderByAsc(OrderBy order) {
        List<Organisation> organisationList = new ArrayList<Organisation>();
        if (order.equals(OrderBy.ASC)) {
            organisationList = organisationRepository.findAllByOrderByOrganisationNameAsc();
        } else if (order.equals(OrderBy.DESC)) {
            organisationList = organisationRepository.findAllByOrderByOrganisationNameDesc();
        }
        return organisationList.stream().map(organisation -> modelMapper.map(organisation, OrganisationDto.class)).toList();
    }

    @Override
    public List<OrganisationDto> getLengthSortedOrder(String field, OrderBy order) {

        List<Organisation> organisationList = new ArrayList<Organisation>();

        if(order.equals(OrderBy.ASC)){
            organisationList = organisationRepository.findAll(Sort.by(Sort.Direction.ASC, field));
        } else if (order.equals(OrderBy.DESC)) {
            organisationList = organisationRepository.findAll(Sort.by(Sort.Direction.DESC, field));
        }
        return organisationList.stream().map(organisation -> modelMapper.map(organisation, OrganisationDto.class)).toList();
    }

    @Override
    public List<DepartmentDto> sendDepartmentList(Long id) {
        Optional<Organisation> organisationOptional = organisationRepository.findById(id);
        List<Department> departments = null;
        if(organisationOptional.isPresent()){
            departments = organisationOptional.get().getDepartmentList();
        }
        return departments.stream().map(department -> modelMapper.map(department, DepartmentDto.class)).toList();
    }

    public AddressDto sendOrganisationAddress(Long id){
        Optional<Organisation> organisationOptional = organisationRepository.findById(id);
        Address address = null;
        if(organisationOptional.isPresent()){
            address = organisationOptional.get().getAddress();
        }
        return modelMapper.map(address,AddressDto.class);
    }


}