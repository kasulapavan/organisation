package net.thrymr.organisation.management.service.serviceInterface;

import net.thrymr.organisation.management.dto.AddressDto;
import net.thrymr.organisation.management.dto.DepartmentDto;
import net.thrymr.organisation.management.dto.OrganisationDto;
import net.thrymr.organisation.management.service.OrderBy;

import java.util.List;

public interface OrganisationService {

    OrganisationDto saveOrganisation(OrganisationDto organisationDto);
    boolean deleteById(Long id);

    List<OrganisationDto> getAll();

    OrganisationDto findById(Long id);

    AddressDto updateAddress(AddressDto addressDto);

    boolean deleteAddressById(Long id);

    List<OrganisationDto> findByOrderByAsc(OrderBy order);

    List<OrganisationDto> getLengthSortedOrder(String field, OrderBy order);

    List<DepartmentDto> sendDepartmentList(Long id);

    AddressDto sendOrganisationAddress(Long id);





}
