package net.thrymr.organisation.management.service.serviceInterface;

import net.thrymr.organisation.management.dto.DepartmentDto;
import net.thrymr.organisation.management.dto.OrganisationDto;

import java.util.List;

public interface DepartmentService {

    String saveDepartment(Long id, DepartmentDto departmentDto);

    List<DepartmentDto>   saveListDepartment(Long id, List<DepartmentDto> departmentDto);

    boolean deleteById(Long id);

    List<DepartmentDto> getAll();

    DepartmentDto updateDepartment(Long id, DepartmentDto departmentDto);



}