package net.thrymr.organisation.management.service;

public enum OrderBy {
    ASC, DESC
}